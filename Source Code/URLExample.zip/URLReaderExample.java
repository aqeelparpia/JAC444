import java.net.*; 
import java.io.*; 

public class URLReaderExample { 
	public static void main(String[] args) throws Exception { 
	
	URL seneca = new 
	URL(" https://ict.senecacollege.ca/course/jav745?q=course/jav745 "); 

	BufferedReader in = new BufferedReader( new InputStreamReader(seneca.openStream())); 
	
	String inputLine = ""; 

	while (inputLine != null){ 
		inputLine = in.readLine();
		System.out.println(inputLine);
	}
	in.close(); 
	} 
}
