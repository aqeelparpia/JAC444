import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class URItoURL {
		public static void main(String[] args) {

			try {
				//URI uri = new URI("db://username:password@myserver.com:5000/catalogue/phones?os=android#samsung");
				URI uri = new URI("http://username:password@myserver.com:5000/catalogue/phones?os=android#samsung");
				//URI baseURI = new URI(http://username:password@myserver.com:5000);
				
				//Relative URI
				//URI uri = new URI("/catalogue/phones?os=android#samsung");
				//URI resolvedURI = baseURI.resolve(uri);
				// URL url = resolvedURI.toURL();
				
				URL url = uri.toURL();
				System.out.println("URL = "+url);
				
				
			}catch(URISyntaxException e) {
				System.out.println("URI Bad Syntax: "+e.getMessage());
			}catch(MalformedURLException e) {
				System.out.println("URL Malformed: "+ e.getMessage());
			}
			
			
		}

	

}
